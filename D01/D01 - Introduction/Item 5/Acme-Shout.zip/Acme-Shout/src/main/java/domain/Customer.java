
package domain;

import javax.persistence.Entity;

@Entity
public class Customer extends Actor {

	// Constructors

	public Customer() {
		super();
	}

	// Relationships

}
