
package domain;

public class Sponsor extends Actor {

	// Constructor

	public Sponsor() {
		super();
	}
}
