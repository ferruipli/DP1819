
package domain;


public class Administrator extends Actor {

	// Constructors

	public Administrator() {
		super();
	}
}
