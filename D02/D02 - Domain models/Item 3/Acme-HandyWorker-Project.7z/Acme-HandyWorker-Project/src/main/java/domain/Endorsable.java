
package domain;

public abstract class Endorsable extends Actor {

	// Constructor

	public Endorsable() {
		super();
	}

}
