
package domain;

public class Referee extends Actor {

	// Constructor

	public Referee() {
		super();
	}
}
