
package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.PhaseRepository;
import domain.FixUpTask;
import domain.HandyWorker;
import domain.Phase;

@Service
@Transactional
public class PhaseService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private PhaseRepository		phaseRepository;

	// Supporting services ----------------------------------------------------

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private FixUpTaskService	fixUpTaskService;


	// Constructor ------------------------------------------------------------

	public PhaseService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Phase create() {
		Phase result;

		result = new Phase();

		return result;
	}

	public Phase save(final Phase phase) { // Updating
		return this.save(null, phase);
	}

	public Phase save(FixUpTask fixUpTask, final Phase phase) { // Creating
		Assert.notNull(phase);
		Assert.isTrue(phase.getStartMoment().before(phase.getEndMoment()));

		Phase result;
		boolean isUpdating;

		isUpdating = this.phaseRepository.exists(phase.getId());

		if (isUpdating) {
			this.checkOwner(phase);
			fixUpTask = this.fixUpTaskService.findByPhaseId(phase.getId());
		} else
			this.checkHandyWorkerAccess(fixUpTask, phase);

		Assert.notNull(fixUpTask);
		this.checkPhaseDate(fixUpTask, phase);

		result = this.phaseRepository.save(phase);

		if (!isUpdating)
			this.fixUpTaskService.addNewPhase(fixUpTask, result);

		return result;
	}

	public void delete(final Phase phase) {
		Assert.notNull(phase);
		Assert.isTrue(this.phaseRepository.exists(phase.getId()));
		this.checkOwner(phase);

		FixUpTask fixUpTask;

		fixUpTask = this.fixUpTaskService.findByPhaseId(phase.getId());
		this.fixUpTaskService.removePhase(fixUpTask, phase);

		this.phaseRepository.delete(phase);
	}

	public Phase findOne(final int phaseId) {
		Phase result;

		result = this.phaseRepository.findOne(phaseId);
		Assert.notNull(result);

		return result;
	}

	// Other business methods -------------------------------------------------

	public Collection<Phase> findByFixUpTaskIdOrdered(final int fixUpTaskId) {
		Collection<Phase> result;

		result = this.phaseRepository.findByFixUpTaskIdOrdered(fixUpTaskId);
		Assert.notNull(result);

		return result;
	}

	private void checkOwner(final Phase phase) {
		HandyWorker principal;
		int principalId, ownerId;

		principal = this.handyWorkerService.findByPrincipal();
		principalId = principal.getId();
		ownerId = this.handyWorkerService.findPhaseCreator(phase);

		Assert.isTrue(principalId == ownerId);
	}

	private void checkHandyWorkerAccess(final FixUpTask fixUpTask, final Phase phase) {
		HandyWorker principal;
		Collection<FixUpTask> workableFixUpTasks;

		principal = this.handyWorkerService.findByPrincipal();
		workableFixUpTasks = this.fixUpTaskService.findWorkableFixUpTasks(principal.getId());

		Assert.isTrue(workableFixUpTasks.contains(fixUpTask));
	}

	private void checkPhaseDate(final FixUpTask fixUpTask, final Phase phase) {
		Assert.isTrue(phase.getStartMoment().after(fixUpTask.getStartDate()) && phase.getStartMoment().before(fixUpTask.getEndDate()));
		Assert.isTrue(phase.getEndMoment().after(fixUpTask.getStartDate()) && phase.getEndMoment().before(fixUpTask.getEndDate()));
	}
}
