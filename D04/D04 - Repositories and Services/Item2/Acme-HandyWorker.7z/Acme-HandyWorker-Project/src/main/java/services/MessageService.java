
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.MessageRepository;
import domain.Actor;
import domain.Application;
import domain.Box;
import domain.Customer;
import domain.HandyWorker;
import domain.Message;

@Service
@Transactional
public class MessageService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private MessageRepository		messageRepository;

	// Supporting services ----------------------------------------------------

	@Autowired
	private ActorService			actorService;

	@Autowired
	private BoxService				boxService;

	@Autowired
	private CustomisationService	customisationService;


	// Constructors -----------------------------------------------------------

	public MessageService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Message create() {
		Message result;
		Collection<Actor> recipients;
		final Actor sender = this.actorService.findPrincipal();
		Date sendMoment;
		Assert.notNull(sender);

		result = new Message();
		recipients = new ArrayList<Actor>();
		sendMoment = new Date();

		result.setSender(sender);
		result.setRecipients(recipients);
		result.setSendMoment(sendMoment);
		result.setIsSpam(false);

		return result;
	}

	public Message findOne(final int IdMessage) {
		Assert.isTrue(IdMessage != 0);
		Message result;
		result = this.messageRepository.findOne(IdMessage);
		Assert.notNull(result);
		return result;
	}

	public Collection<Message> findAll() {
		Collection<Message> result;
		result = this.messageRepository.findAll();
		return result;
	}

	public Message save(final Message message) {
		Assert.notNull(message.getSender());
		Assert.notNull(message.getRecipients());
		Assert.notNull(message);
		Assert.isTrue(message.getId() == 0);

		Date sendMoment;
		sendMoment = new Date();
		message.setSendMoment(sendMoment);

		final Message result;
		final Actor sender = this.actorService.findPrincipal();
		final Collection<Actor> recipients = message.getRecipients();
		final Box outBoxSender = this.boxService.searchBox(sender, "out box");

		Assert.isTrue(message.getSender().equals(sender));

		if (this.isSpamMessage(message))
			message.setIsSpam(true);
		else
			message.setIsSpam(false);

		result = this.messageRepository.save(message);

		if (message.getIsSpam()) {
			this.actorService.isSuspicious(sender);
			for (final Actor r : recipients) {
				final Box spamBoxRecipiens = this.boxService.searchBox(r, "spam box");
				spamBoxRecipiens.getMessages().add(result);
			}
		} else
			for (final Actor r : recipients) {
				final Box inBoxRecipiens = this.boxService.searchBox(r, "in box");
				inBoxRecipiens.getMessages().add(result);
			}
		outBoxSender.getMessages().add(result);

		Assert.notNull(result);
		return result;
	}
	public void delete(final Message message) {
		Assert.notNull(message);
		Assert.notNull(this.messageRepository.findOne(message.getId()));
		final Actor actor = this.actorService.findPrincipal();
		Assert.isTrue((message.getSender().equals(actor)) || (message.getRecipients().contains(actor)));
		final Box trashBoxActor = this.boxService.searchBox(actor, "trash box");
		final Collection<Message> messagesTrashBox = trashBoxActor.getMessages();
		if (messagesTrashBox.contains(message)) {
			messagesTrashBox.remove(message);
			this.deleteMessageBD(message, actor);
		} else {
			this.deleteMessageAllBoxActor(actor, message);
			trashBoxActor.getMessages().add(message);
		}

	}

	// Other business methods -------------------------------------------------

	public boolean isSpamMessage(final Message message) {
		boolean res = false;
		final Collection<String> spamWords = this.customisationService.find().getSpamWords();
		for (final String sw : spamWords)
			if (message.getSubject().contains(sw) || message.getBody().contains(sw))
				res = true;
		return res;
	}

	private void deleteMessageAllBoxActor(final Actor actor, final Message message) {
		final Collection<Box> findAllBoxByActor = this.boxService.findAllBoxByActor(actor);
		for (final Box b : findAllBoxByActor)
			if (b.getMessages().contains(message))
				b.getMessages().remove(message);
	}

	private void deleteMessageBD(final Message message, final Actor actor) {
		if (this.boxService.boxWithMessage(message).isEmpty())
			this.messageRepository.delete(message);
	}

	public void moveMessageFromBoxToBox(final Box boxInicio, final Box boxFin, final Message message) {
		final Actor actor = this.actorService.findPrincipal();

		Assert.isTrue((boxInicio.getActor().equals(actor)) && (boxFin.getActor().equals(actor)));
		Assert.isTrue(boxInicio.getMessages().contains(message));
		Assert.isTrue(!(boxFin.getMessages().contains(message)));
		Assert.notNull(message);
		Assert.notNull(boxInicio);
		Assert.notNull(boxFin);

		boxInicio.getMessages().remove(message);
		boxFin.getMessages().add(message);
	}

	public void messageToStatus(final Application application, final String status) {
		final Actor systemActor = this.actorService.findPrincipal();
		final Message messageHandyWorker;
		final Message messageCustomer;
		final Message messageSaveHandyWorker;
		final Message messageSaveCustomer;

		HandyWorker handyWorkerApplication;
		Customer customerApplication;

		handyWorkerApplication = application.getHandyWorker();
		customerApplication = application.getFixUpTask().getCustomer();

		Box inBoxHandyWorker;
		Box inBoxCustomer;
		Box outBoxSystemActor;

		outBoxSystemActor = this.boxService.searchBox(systemActor, "out box");
		inBoxHandyWorker = this.boxService.searchBox(handyWorkerApplication, "in box");
		inBoxCustomer = this.boxService.searchBox(customerApplication, "in box");

		messageHandyWorker = new Message();
		messageCustomer = new Message();
		String statusEn = null;
		String statusEs = null;
		if (status.equals("REJECTED")) {
			statusEn = "reject";
			statusEs = "rechazado";
		}
		if (status.equals("ACCEPTED")) {
			statusEn = "acepted";
			statusEs = "aceptado";
		}

		messageHandyWorker.setSender(systemActor);
		messageHandyWorker.setSubject("Status changed");
		messageHandyWorker.setBody("The status for application  assigned to fix-up task whose ticker is " + application.getFixUpTask().getTicker() + " is change to " + statusEn
			+ " status.\nEl estado de la solicitud asignada a la tarea de reparaci�n cuyo ticker es " + application.getFixUpTask().getTicker() + " ha cambiado a estado" + statusEs + ".");
		messageHandyWorker.setPriority("HIGH");
		Date sendMoment;
		sendMoment = new Date();
		messageHandyWorker.setSendMoment(sendMoment);
		final List<Actor> recipients = new ArrayList<Actor>();
		recipients.add(handyWorkerApplication);
		messageHandyWorker.setRecipients(recipients);

		messageSaveHandyWorker = this.messageRepository.save(messageHandyWorker);
		inBoxHandyWorker.getMessages().add(messageSaveHandyWorker);
		outBoxSystemActor.getMessages().add(messageSaveHandyWorker);

		messageCustomer.setSender(systemActor);
		messageCustomer.setSubject("Status changed");
		messageCustomer.setBody("The status for application  assigned to fix-up task whose ticker is " + application.getFixUpTask().getTicker() + " is change to " + statusEn
			+ " status.\nEl estado de la solicitud asignada a la tarea de reparaci�n cuyo ticker es " + application.getFixUpTask().getTicker() + " ha cambiado a estado " + statusEs + ".");
		messageCustomer.setPriority("HIGH");
		Date sendMoment2;
		sendMoment2 = new Date();
		messageCustomer.setSendMoment(sendMoment2);
		final List<Actor> recipients2 = new ArrayList<Actor>();
		recipients2.add(customerApplication);
		messageCustomer.setRecipients(recipients2);

		messageSaveCustomer = this.messageRepository.save(messageCustomer);
		inBoxCustomer.getMessages().add(messageSaveCustomer);
		outBoxSystemActor.getMessages().add(messageSaveCustomer);

		Assert.notNull(messageSaveHandyWorker);
		Assert.notNull(messageSaveCustomer);
	}
}
